import argparse

"""
    wadegiles -p taibei,gaoxiong
    >>>taipei,kaohsiung
    wadegiles -w taipei
    >>>taibei
    wadegiles -h
"""
pinyin_to_wade = {
        "a": "a",
        "ai": "ai",
        "an": "an",
        "ang": "ang",
        "ao": "ao",
        "cha": "zha",
        "chai": "zhai",
        "chan": "zhan"}

wade_to_pinyin = {v: k for k, v in pinyin_to_wade.items()}

def convert_to_pinyin(wade):
    pinyin = []
    wade = wade.split()
    for w in wade: 
        if w in wade_to_pinyin:
            pinyin.append(wade_to_pinyin[w])
        else:
            pinyin.append(w)
    return " ".join(pinyin)

def convert_to_wade(pinyin):
    wade = []
    pinyin = pinyin.split()
    for p in pinyin:
        if p in pinyin_to_wade:
            wade.append(pinyin_to_wade[p])
        else:
            wade.append(p)
    return " ".join(wade)

def main():
    parser = argparse.ArgumentParser(description='Convert Between Wade-Giles Pinyin to Pinyin')
    parser.add_argument('input',type=str, help='Input Text')
    parser.add_argument('-w', '--wade', action='store_true', help='Convert to Wade-Giles Pinyin')
    parser.add_argument('-p', '--pinyin', action='store_true', help='Convert to Pinyin')
    args = parser.parse_args()

    if args.wade:
        result = convert_to_wade(args.input)
    elif args.pinyin:
        result = convert_to_pinyin(args.input)
    else:
        parser.print_help()
        return
    print(result)

if __name__ == '__main__': 
    main()
